import os
from openstack import connection

os.environ.setdefault('OS_CDN_ENDPOINT_OVERRIDE',
                      'https://cdn.myhuaweicloud.com/v1.0/')  # CDN API url,example:https://cdn.myhuaweicloud.com/v1.0/

# AKSK Auth" 
projectId = "085ab0c0b6800f6c2f0dc00861bfd04d"  # Project ID of cn-north-1
cloud = "cdn.myhuaweicloud.com"  # cdn use: cloud = "myhuaweicloud.com"
region = "cn-north-1"  # example: region = "cn-north-1"
AK = "REP34APMJZHUBK0JWIP1"
SK = "avw4tT8NAEib9SFfGRwDARRydlUQAGb6DaF4eiAJ"

conn = connection.Connection(
    project_id=projectId,
    cloud=cloud,
    region=region,
    ak=AK,
    sk=SK)
# new version API
# part 3: Refreshing and Preheating
# Creating a Cache Refreshing Task
def refresh_create(_refresh_task):
    print("refresh files or dirs:")
    task = conn.cdn.create_refresh_task(**_refresh_task)
    print(task)


if __name__ == "__main__":
    # new version API
    # part 3: Refreshing and Preheating
    # Creating a Cache Refreshing Task
  refresh_dir_task = {
        "type": "directory",
        "urls": ["https://lighting.leansite-cloud.com/"]
    }
  refresh_create(refresh_dir_task)

