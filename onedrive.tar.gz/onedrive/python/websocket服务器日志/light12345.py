import queue
import threading
import paramiko
from queue import Queue
from paramiko_expect import SSHClientInteraction
from SimpleWebSocketServer import SimpleWebSocketServer, WebSocket


def output_func(msg, ):
    q.put(msg)


def conn_tail(log_file):
    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy)
        client.connect('172.31.16.90', 22, 'rizhi', password='123456')
        interact = SSHClientInteraction(client, timeout=1, display=False)
        interact.send('tail -f %s' % log_file)
        interact.tail(output_callback=output_func, timeout=1024654)
    except Exception as e:
        print(e)


class WSServerInstance(WebSocket):
    def handleMessage(self):
        # 这里的server就是绑定的WSServer里的server
        self.server.data_queue.put(self.data)

    def handleConnected(self):
        print(self.address, "connected")

    def handleClose(self):
        print(self.address, "closed")


class WSServer(object):
    def __init__(self, port):
        self.server = SimpleWebSocketServer('0.0.0.0', '12345', WSServerInstance)
        self.server.data_queue = queue.Queue(1000)
        self.server_thread = None
        self.run()

    def run(self):
        self.server_thread = threading.Thread(target=self.run_server)
        self.server_thread.start()

    def run_server(self):
        self.server.serveforever()

    def broadcast_message(self):
        """
            广播消息，向所有连接中的client发消息
        """
        while True:
            data = q.get()

            for key, client in self.server.connections.items():
                client.sendMessage(data)

    def main_proccess(self):
        """
           主循环，可以加一些其他流程的代码
        """
        while True:
            self.broadcast_message()


if __name__ == '__main__':
    q = Queue()
    t = threading.Thread(target=conn_tail, args=('/home/software/log/dhlk_light_service-1.0-SNAPSHOT.jar.log',))
    t.start()
    ws_server = WSServer(8888)
    ws_server.main_proccess()
