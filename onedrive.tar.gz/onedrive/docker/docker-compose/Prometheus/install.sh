#！/bin/bash
mkdir -p /home/prom/{prometheus,prometheus/data,alertmanager,grafana}

chmod 777 /home/prom/{prometheus/data,grafana}

cd /home/prom