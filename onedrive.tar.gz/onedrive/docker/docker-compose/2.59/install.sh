#!/bin/bash
set -e

IP=192.168.2.59

yum install -y wget git >/dev/null
wget https://pkg.rainbond.com/releases/common/v5.1/grctl && chmod +x ./grctl
./grctl init --iip ${IP} --domain apps.dh.com
if [ $? != 0 ];then
    echo "云帮安装未成功，不能继续"
fi


mkdir -p /etc/cassandra/data
mkdir -p /var/lib/postgres
mkdir -p /opt/light
mkdir -p /var/lib/redis
mkdir -p /etc/docker/certs.d/hub.dh.com
sshpass -p 1111 scp 192.168.1.6:/etc/docker/certs.d/hub.dh.com/* /etc/docker/certs.d/hub.dh.com/
systemctl restart docker

cp cassandra.yaml /etc/cassandra/cassandra.yaml
cp docker-compose.yml /opt/light/
cp docker-compose /usr/local/bin/ && chmod +x /usr/local/bin/docker-compose
sed -i "s/192.168.2.59/${IP}/" /opt/light/docker-compose.yml
cd /opt/light && docker-compose up -d
