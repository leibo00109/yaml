/*
Navicat MySQL Data Transfer

Source Server         : 192.168.2.222
Source Server Version : 50726
Source Host           : 192.168.2.222:3306
Source Database       : standard_light

Target Server Type    : MYSQL
Target Server Version : 50726
File Encoding         : 65001

Date: 2019-07-22 15:05:01
*/

SET FOREIGN_KEY_CHECKS=0;
USE sys_menu;
-- ----------------------------
-- Table structure for sys_menu
-- ----------------------------
DROP TABLE IF EXISTS `sys_menu`;
CREATE TABLE `sys_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_name` varchar(50) NOT NULL,
  `order_num` varchar(10) DEFAULT NULL,
  `request_addr` varchar(50) DEFAULT NULL,
  `type` varchar(10) DEFAULT NULL,
  `visible` varchar(10) DEFAULT NULL,
  `permission_id` varchar(50) DEFAULT NULL,
  `point` text,
  `parent_id` int(11) DEFAULT NULL,
  `icon` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sys_menu
-- ----------------------------
INSERT INTO `sys_menu` VALUES ('1', '总览信息', '1', 'LightOverview', 'C', '1', 'api:v1:home:view', '当前总览信息:api/v1/home/getHomeTop,当前设置总览:api/v1/home/currentSetInfo,历史15min:api/v1/home/historyDayByMin,历史1hour:api/v1/home/historyDayByHour,历史1day:api/v1/home/historyMonthByEveryday,历史1week:api/v1/home/getHistoryEnergyByWeek,历史1month:api/v1/home/getHistoryEnergyByMonth,历史1quarter:api/v1/home/getHistoryEnergyByQuarter,历史1year:api/v1/home/getHistoryEnergyByYear', '0', '#');
INSERT INTO `sys_menu` VALUES ('2', '照明控制', '2', 'LightCtrl', 'C', '1', 'api:v1:control:view', '开关灯:api/v1/control/switch,人感信息:api/v1/control/peoplefeeling,分组列表:api/v1/control/category/list,分组新增:api/v1/control/category/save,分组删除:api/v1/control/category/remove,获取区域:api/v1/control/zone/list', '0', '#');
INSERT INTO `sys_menu` VALUES ('3', '能源管理', '3', 'LightEnergy', 'C', '1', 'api:v1:manage:view', '获取单灯24小时的平均电流和电压:api/v1/manage/power/analyse,获取区域:api/v1/manage/zone/list', '0', '#');
INSERT INTO `sys_menu` VALUES ('4', '能源统计', '4', 'LightStatistics', 'C', '1', 'api:v1:lightPower:view', '能耗信息:api/v1/lightPower/find/CurDayHourPower,区域表单:api/v1/lightPower/find/area,统计报表:api/v1/lightPower/find/powerByConditon', '0', '#');
INSERT INTO `sys_menu` VALUES ('5', '实时故障', '5', 'LightFault', 'C', '1', 'api:v1:loseUpInfo:view', '故障列表:api/v1/loseUpInfo/find/loseInfo,故障搜索:api/v1/loseUpInfo/dimQuery/loseInfo,故障是否处理:api/v1/loseUpInfo/update/dealState', '0', '#');
INSERT INTO `sys_menu` VALUES ('6', '定时设置', '6', 'LightTimed', 'C', '1', 'api:v1:schedule:view', '定时新增:api/v1/schedule/save,定时列表:api/v1/schedule/list,定时修改:api/v1/schedule/update,定时删除:api/v1/schedule/remove,定时是否启用:api/v1/schedule/enabled', '0', '#');
INSERT INTO `sys_menu` VALUES ('7', '系统设置', '7', 'LightSystem', 'C', '1', 'api:v1:userDefined:view', '自定义添加:api/v1/userDefined/insertUserDefined,自定义获取:api/v1/userDefined/getUserDefined,自定义修改:api/v1/userDefined/updateUserDefined', '0', '#');
INSERT INTO `sys_menu` VALUES ('8', '意见反馈', '8', 'LightRights', 'C', '1', 'api:v1:feedback:view', '意见新增:api/v1/feedback/insertFeedback', '0', '#');
INSERT INTO `sys_menu` VALUES ('9', '照明设置', '9', 'LightSet', 'C', '1', 'api:v1:lightAllocate:view', '工厂导出:api/v1/lightAllocate/save/configuration_tb,工厂添加:api/v1/lightAllocate/save/conf_area,工厂列表:api/v1/lightAllocate/find/area_conf,工厂删除:api/v1/lightAllocate/del/delConfArea,配灯添加:api/v1/lightAllocate/update/conf_area,配灯导入:api/v1/lightAllocate/find/shortAddrAll,获取列表:api/v1/lightAllocate/find/areaInfoAll', '0', '#');
INSERT INTO `sys_menu` VALUES ('10', '远程人感', '10', 'LightCapacity', 'C', '1', 'api:v1:remote:view', '新增:api/v1/remote/peoplefeeling/save,修改:api/v1/remote/peoplefeeling/update,删除:api/v1/remote/peoplefeeling/remove,获取列表:api/v1/remote/peoplefeeling/list,是否启用:api/v1/remote/peoplefeeling/enabled,下载:api/v1/remote/peoplefeeling/download', '0', '#');
INSERT INTO `sys_menu` VALUES ('11', '远程光感', '11', 'LightRay', 'C', '1', 'api:v1:remote:light:view', '新增:api/v1/remote/light/save,修改:api/v1/remote/light/update,删除:api/v1/remote/light/remove,获取列表:api/v1/remote/light/list,是否启用:api/v1/remote/light/enabled,下载:api/v1/remote/light/download', '0', '#');
