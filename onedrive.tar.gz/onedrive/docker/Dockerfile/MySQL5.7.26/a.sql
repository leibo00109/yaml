set sql_safe_updates=0;
CREATE DATABASE IF NOT EXISTS light_authority default charset utf8 COLLATE utf8_general_ci;
CREATE DATABASE IF NOT EXISTS standard_light default charset utf8 COLLATE utf8_general_ci;
CREATE DATABASE IF NOT EXISTS sys_menu default charset utf8 COLLATE utf8_general_ci;
