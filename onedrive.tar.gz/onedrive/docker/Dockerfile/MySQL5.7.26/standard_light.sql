/*
Navicat MySQL Data Transfer

Source Server         : 192.168.2.222
Source Server Version : 50726
Source Host           : 192.168.2.222:3306
Source Database       : standard_light

Target Server Type    : MYSQL
Target Server Version : 50726
File Encoding         : 65001

Date: 2019-07-22 15:04:52
*/

SET FOREIGN_KEY_CHECKS=0;
USE standard_light;
-- ----------------------------
-- Table structure for light_category
-- ----------------------------
DROP TABLE IF EXISTS `light_category`;
CREATE TABLE `light_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `devices` text,
  `zone_id` int(11) DEFAULT NULL,
  `device_type` int(11) DEFAULT NULL,
  `gmt_create` datetime NOT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `zone_id` (`zone_id`),
  CONSTRAINT `light_category_ibfk_1` FOREIGN KEY (`zone_id`) REFERENCES `light_conf_area_tmp` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for light_command_valid
-- ----------------------------
DROP TABLE IF EXISTS `light_command_valid`;
CREATE TABLE `light_command_valid` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `info` varchar(255) DEFAULT NULL COMMENT '命令内容',
  `type` varchar(255) DEFAULT NULL COMMENT '未通过原因',
  `source` int(11) DEFAULT NULL COMMENT '命令来源（0-mqtt/1-web/2-app）',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=322252 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for light_conf_area_tmp
-- ----------------------------
DROP TABLE IF EXISTS `light_conf_area_tmp`;
CREATE TABLE `light_conf_area_tmp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `area_name` varchar(200) DEFAULT NULL COMMENT '区域名称',
  `comment` varchar(450) DEFAULT NULL COMMENT '备注',
  `percent_size` varchar(100) DEFAULT '60px',
  `pic_url_path` varchar(450) DEFAULT NULL COMMENT '图片路径',
  `light_area_info` longtext COMMENT '灯信息',
  `gmtCreate` varchar(450) DEFAULT NULL,
  `gmtModified` varchar(450) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `area_name_UNIQUE` (`area_name`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for light_conf_area_tmp_app
-- ----------------------------
DROP TABLE IF EXISTS `light_conf_area_tmp_app`;
CREATE TABLE `light_conf_area_tmp_app` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `area_name` varchar(200) DEFAULT NULL COMMENT '区域名称',
  `comment` varchar(450) DEFAULT NULL COMMENT '备注',
  `percent_size` varchar(100) DEFAULT '60px',
  `pic_url_path` varchar(450) DEFAULT NULL COMMENT '图片路径',
  `light_area_info` longtext COMMENT '灯信息',
  `gmtCreate` varchar(450) DEFAULT NULL,
  `gmtModified` varchar(450) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `area_name_UNIQUE` (`area_name`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for light_e3feeling
-- ----------------------------
DROP TABLE IF EXISTS `light_e3feeling`;
CREATE TABLE `light_e3feeling` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `part_addr_num` varchar(255) DEFAULT NULL,
  `devices` TEXT DEFAULT NULL,
  `illuminance` varchar(255) DEFAULT NULL COMMENT '照度',
  `start_time` varchar(255) DEFAULT NULL,
  `end_time` varchar(255) DEFAULT NULL,
  `enabled` int(11) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modify` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for light_everyday_energy
-- ----------------------------
DROP TABLE IF EXISTS `light_everyday_energy`;
CREATE TABLE `light_everyday_energy` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `today_date` varchar(255) DEFAULT NULL COMMENT '每日时间',
  `today_energy` float DEFAULT NULL COMMENT '当日总能耗',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for light_faultmsg
-- ----------------------------
DROP TABLE IF EXISTS `light_faultmsg`;
CREATE TABLE `light_faultmsg` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `short_addr` int(11) DEFAULT NULL COMMENT '短地址',
  `device_type` int(11) DEFAULT NULL COMMENT '设备类型（1-灯）（2-开关）',
  `name` varchar(255) DEFAULT NULL COMMENT '故障标题',
  `info` varchar(255) DEFAULT NULL COMMENT '故障内容',
  `state` int(11) DEFAULT NULL COMMENT '状态（0-离线/1-恢复上线/2-异常）',
  `online_time` varchar(255) DEFAULT NULL COMMENT '上线时间',
  `offline_time` varchar(255) DEFAULT NULL COMMENT '离线时间',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `deal_state` int(11) DEFAULT NULL COMMENT '处理状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=208624 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for light_info
-- ----------------------------
DROP TABLE IF EXISTS `light_info`;
CREATE TABLE `light_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `zone_id` int(11) DEFAULT NULL COMMENT '厂区id',
  `category_id` int(11) DEFAULT NULL COMMENT '分组id',
  `part_num` varchar(255) DEFAULT NULL COMMENT '段号',
  `addr_num` varchar(255) DEFAULT NULL COMMENT '地址号',
  `short_addr` int(11) DEFAULT NULL COMMENT '短地址',
  `type` int(11) DEFAULT NULL COMMENT '设备类型(0-灯/1-开关)',
  `ind_bright` int(11) DEFAULT NULL COMMENT '人感感应亮度',
  `unind_bright` int(11) DEFAULT NULL COMMENT '人感未感应亮度',
  `ind_time` int(11) DEFAULT NULL COMMENT '人感感应时间',
  `state` int(11) DEFAULT NULL COMMENT '人感感应开启状态（0-未开启；1-开启）',
  `x_axis` decimal(20,8) DEFAULT NULL COMMENT 'x轴',
  `y_axis` decimal(20,8) DEFAULT NULL COMMENT 'y轴',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `short_addr_UNIQUE` (`short_addr`),
  KEY `zone_id` (`zone_id`)
) ENGINE=InnoDB AUTO_INCREMENT=301 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for light_peoplefeeling
-- ----------------------------
DROP TABLE IF EXISTS `light_peoplefeeling`;
CREATE TABLE `light_peoplefeeling` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `part_addr_num` text COMMENT '短号+地址号,用-分割\\\\n01000008-02000002',
  `devices` text COMMENT '同上',
  `state` int(255) DEFAULT NULL,
  `ind_birght` int(255) DEFAULT NULL COMMENT '感应亮度',
  `unind_bright` int(255) DEFAULT NULL COMMENT '未感应亮度',
  `ind_time` int(11) DEFAULT NULL COMMENT '感应时间',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modify` datetime DEFAULT NULL COMMENT '修改时间',
  `enabled` int(255) DEFAULT NULL COMMENT '0--关闭  1---开启',
  `remark` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Table structure for light_schedule
-- ----------------------------
DROP TABLE IF EXISTS `light_schedule`;
CREATE TABLE `light_schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `zone_id` int(11) DEFAULT NULL,
  `category_id` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `week` varchar(255) NOT NULL,
  `time` varchar(255) NOT NULL,
  `expression` varchar(255) NOT NULL,
  `address` text,
  `description` varchar(255) DEFAULT NULL,
  `enabled` int(255) NOT NULL COMMENT '0-未开启；1-开启',
  `gmt_create` datetime NOT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `zone_id` (`zone_id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `light_schedule_ibfk_1` FOREIGN KEY (`zone_id`) REFERENCES `light_conf_area_tmp` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `light_schedule_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `light_category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for light_statistics
-- ----------------------------
DROP TABLE IF EXISTS `light_statistics`;
CREATE TABLE `light_statistics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `start_time` varchar(255) DEFAULT NULL,
  `end_time` varchar(255) DEFAULT NULL,
  `duration` bigint(20) DEFAULT NULL,
  `short_addr` int(11) DEFAULT NULL,
  `max_elec` decimal(20,8) DEFAULT NULL,
  `max_volt` decimal(20,8) DEFAULT NULL,
  `min_elec` decimal(20,8) DEFAULT NULL,
  `min_volt` decimal(20,8) DEFAULT NULL,
  `aver_power` decimal(20,8) DEFAULT NULL,
  `total_energy` decimal(20,8) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2169 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for light_statistics_confirm
-- ----------------------------
DROP TABLE IF EXISTS `light_statistics_confirm`;
CREATE TABLE `light_statistics_confirm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time_segment` int(11) NOT NULL,
  `confirm_segment` varchar(450) DEFAULT NULL,
  `cal_against` int(11) DEFAULT NULL,
  `cal_time` varchar(450) DEFAULT NULL,
  `gmt_create` varchar(450) DEFAULT NULL,
  `gmt_modified` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for light_zone_day_energy
-- ----------------------------
DROP TABLE IF EXISTS `light_zone_day_energy`;
CREATE TABLE `light_zone_day_energy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(255) DEFAULT NULL,
  `data` text,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `date` (`date`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for sys_feedback
-- ----------------------------
DROP TABLE IF EXISTS `sys_feedback`;
CREATE TABLE `sys_feedback` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id ',
  `introduction` varchar(255) DEFAULT NULL COMMENT '意见简介',
  `type` int(11) DEFAULT NULL COMMENT '意见类型（1-报错，2-意见，3-其他，4-体验问题）',
  `info` text COMMENT '意见内容',
  `phone` varchar(255) DEFAULT NULL COMMENT '反馈人电话',
  `state` int(11) DEFAULT NULL COMMENT '意见处理状态(0-未处理，1-已处理)',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for sys_menu
-- ----------------------------
DROP TABLE IF EXISTS `sys_menu`;
CREATE TABLE `sys_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_name` varchar(50) NOT NULL,
  `order_num` varchar(10) DEFAULT NULL,
  `request_addr` varchar(50) DEFAULT NULL,
  `type` varchar(10) DEFAULT NULL,
  `visible` varchar(10) DEFAULT NULL,
  `permission_id` varchar(50) DEFAULT NULL,
  `point` text,
  `parent_id` int(11) DEFAULT NULL,
  `icon` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for sys_operate_info
-- ----------------------------
DROP TABLE IF EXISTS `sys_operate_info`;
CREATE TABLE `sys_operate_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `time` varchar(255) DEFAULT NULL COMMENT '操作时间',
  `operator` varchar(255) DEFAULT NULL COMMENT '操作人',
  `operate_type` varchar(255) DEFAULT NULL COMMENT '操作类型',
  `short_addr` int(11) DEFAULT NULL COMMENT '短地址',
  `source` varchar(255) DEFAULT NULL COMMENT '操作来源',
  `info` varchar(512) DEFAULT NULL COMMENT '操作详情',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for sys_user_defined
-- ----------------------------
DROP TABLE IF EXISTS `sys_user_defined`;
CREATE TABLE `sys_user_defined` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `logow` blob COMMENT 'logo外',
  `title_style` text COMMENT '标题样式',
  `Logon1` blob COMMENT 'logo内1',
  `Logon2` blob COMMENT 'logo内2',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for sys_warnorder_info
-- ----------------------------
DROP TABLE IF EXISTS `sys_warnorder_info`;
CREATE TABLE `sys_warnorder_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `now_time` varchar(500) NOT NULL,
  `short_addr` varchar(45) NOT NULL,
  `order_info` varchar(450) NOT NULL,
  `info` varchar(500) NOT NULL,
  `warn_type` varchar(45) DEFAULT NULL,
  `gmt_create` varchar(45) DEFAULT NULL,
  `gmt_modified` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5812923 DEFAULT CHARSET=utf8;
