set sql_safe_updates=0;
CREATE DATABASE IF NOT EXISTS light_v3 default charset utf8 COLLATE utf8_general_ci;
USE light_v3;
SET FOREIGN_KEY_CHECKS=0;
CREATE TABLE `light_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `devices` text,
  `zone_id` int(11) DEFAULT NULL,
  `device_type` int(11) DEFAULT NULL,
  `gmt_create` datetime NOT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `zone_id` (`zone_id`),
  CONSTRAINT `light_category_ibfk_1` FOREIGN KEY (`zone_id`) REFERENCES `light_conf_area_tmp` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

CREATE TABLE `light_conf_area_tmp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `area_name` varchar(200) DEFAULT NULL COMMENT '区域名称',
  `comment` varchar(450) DEFAULT NULL COMMENT '备注',
  `percent_size` varchar(100) DEFAULT '60px',
  `pic_url_path` varchar(450) DEFAULT NULL COMMENT '图片路径',
  `light_area_info` longtext COMMENT '灯信息',
  `gmt_create` varchar(450) DEFAULT NULL,
  `gmt_modified` varchar(450) DEFAULT NULL,
  `device_type` varchar(10) DEFAULT NULL COMMENT 'app / web',
  PRIMARY KEY (`id`),
  UNIQUE KEY `area_name_UNIQUE` (`area_name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

CREATE TABLE `light_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `short_addr` varchar(128) DEFAULT NULL COMMENT '短地址',
  `type` int(11) DEFAULT NULL COMMENT '设备类型(1-灯/2-人感/3-光感/4-开关)',
  `ind_bright` int(11) DEFAULT NULL COMMENT '人感感应亮度',
  `unind_bright` int(11) DEFAULT NULL COMMENT '人感未感应亮度',
  `ind_time` int(11) DEFAULT NULL COMMENT '人感感应时间',
  `state` int(11) DEFAULT NULL COMMENT '人感感应开启状态（0-未开启；1-开启）',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间-->初始上线时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

CREATE TABLE `light_schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '定时名称',
  `zone_id` int(11) DEFAULT NULL COMMENT '区域id',
  `category_id` int(11) NOT NULL COMMENT '分组id',
  `type` int(11) NOT NULL COMMENT '设备状态',
  `week` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '周',
  `time` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '时间',
  `expression` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '定时格式',
  `address` text CHARACTER SET utf8 COMMENT '灯id',
  `description` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '描述',
  `enabled` int(255) NOT NULL COMMENT '是否启用（0-未开启；1-开启）',
  `gmt_create` datetime NOT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

CREATE TABLE `lightctrl_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `operator_name` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `operator_ip` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `time_key` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `operate_time` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `ctrl_command` text COLLATE utf8_bin,
  `ctrl_order` text COLLATE utf8_bin,
  `short_addrs` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `type` tinyint(255) DEFAULT NULL,
  `operate_result` tinyint(255) DEFAULT NULL,
  `back_result` tinyint(4) DEFAULT NULL,
  `gmt_create` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `gmt_modify` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

CREATE TABLE `schedule_result` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `light_schedule_id` int(11) DEFAULT NULL COMMENT '定时设置id',
  `operate` varchar(255) COLLATE utf8_bin DEFAULT NULL COMMENT '开关灯',
  `return_result` varchar(255) COLLATE utf8_bin DEFAULT NULL COMMENT '定时执行结果',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

CREATE TABLE `sys_feedback` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id ',
  `introduction` varchar(255) DEFAULT NULL COMMENT '意见简介',
  `type` int(11) DEFAULT NULL COMMENT '意见类型（1-报错，2-意见，3-其他，4-体验问题）',
  `info` text COMMENT '意见内容',
  `phone` varchar(255) DEFAULT NULL COMMENT '反馈人电话',
  `state` int(11) DEFAULT NULL COMMENT '意见处理状态(0-未处理，1-已处理)',
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `sys_user_defined` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `logow` blob COMMENT 'logo外',
  `title_style` text CHARACTER SET utf8 COMMENT '标题样式',
  `Logon1` blob COMMENT 'logo内1',
  `Logon2` blob COMMENT 'logo内2',
  `web_maps` mediumblob,
  `header_map` blob,
  `gmt_create` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
SET FOREIGN_KEY_CHECKS=1;

