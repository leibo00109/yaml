#!/bin/bash
/usr/bin/ansible-playbook  reset.yml
