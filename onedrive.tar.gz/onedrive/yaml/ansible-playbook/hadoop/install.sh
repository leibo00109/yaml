#!/bin/bash

/usr/bin/ansible-playbook 01-all.yml

wait
/usr/bin/ansible-playbook 02-nn.yml

wait
/usr/bin/ansible-playbook 03-cm.yml

wait
/usr/bin/ansible-playbook 04-clear.yml
