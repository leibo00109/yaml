create temporary tablespace user_temp1
tempfile '/vdb/oracle/oradata/user_temp1.dbf' 
size 50m 
autoextend on 
next 50m maxsize 2048m 
extent management local;

create tablespace user_data1
logging 
datafile '/vdb/oracle/oradata/user_data1.dbf' 
size 50m 
autoextend on 
next 50m maxsize 20480m 
extent management local; 

create user username1 identified by password1
default tablespace user_data1
temporary tablespace user_temp1;

grant connect,resource,dba to username1; 

create temporary tablespace user_temp2
tempfile '/vdb/oracle/oradata/user_temp2.dbf'     
size 50m 
autoextend on 
next 50m maxsize 2048m 
extent management local;

create tablespace user_data2
logging 
datafile '/vdb/oracle/oradata/user_data2.dbf'     
size 50m 
autoextend on 
next 50m maxsize 20480m
extent management local; 

create user username2 identified by password2
default tablespace user_data2
temporary tablespace user_temp2;

grant connect,resource,dba to username2; 

create temporary tablespace user_temp3
tempfile '/vdb/oracle/oradata/user_temp3.dbf'     
size 50m 
autoextend on 
next 50m maxsize 2048m 
extent management local;

create tablespace user_data3
logging 
datafile '/vdb/oracle/oradata/user_data3.dbf'     
size 50m 
autoextend on 
next 50m maxsize 20480m
extent management local; 

create user username3 identified by password3
default tablespace user_data3
temporary tablespace user_temp3;

grant connect,resource,dba to username3; 

