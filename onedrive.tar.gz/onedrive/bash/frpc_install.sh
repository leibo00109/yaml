#!/bin/bash
start(){
	echo "正在安装........"

	curl -O www.dahanglink.com/download/dd.tar.gz &>/dev/null

	if [[ ! -f dd.tar.gz ]];then

		echo "dd.tar.gz文件不存在"
		exit 1

	fi

	tar zxf dd.tar.gz && rm -f dd.tar.gz

	mv -f frpc /usr/bin/frpc && chmod +x /usr/bin/frpc

	if [[ ! -d /etc/frp ]]; then
		
		mkdir /etc/frp 
	fi

	sed -i "s/dhlk/$1/g" frpc.ini && mv -f frpc.ini /etc/frp/

	mv -f frpc.service /usr/lib/systemd/system/ && systemctl enable frpc &>/dev/null

	systemctl start frpc

	if [ $? -eq 0 ];then

		echo "安装完成,项目简称为: $1"

	fi
}

if [[ $# < 1 ]];then

	echo "请带参数，参数为项目名.格式如：./frpc wxwf"
	exit 1

fi

start $1

rm -f frpc*