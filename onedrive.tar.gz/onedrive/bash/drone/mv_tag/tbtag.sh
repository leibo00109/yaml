#!/bin/bash
DRONE_BUILD_NUMBER=$1
RENUM=$(grep hub.dh.com/iot/thingsboard /opt/light/docker-compose.yml | cut -d : -f 3)
sed -i "s?hub.dh.com/iot/thingsboard:${RENUM}?hub.dh.com/iot/thingsboard:${DRONE_BUILD_NUMBER}?" /opt/light/docker-compose.yml
docker stop tb >/dev/null
docker rm tb >/dev/null
cd /opt/light && docker-compose up -d

