#!/bin/bash
DRONE_BUILD_NUMBER=$1
RENUM=$(grep hub.dh.com/leansite/auth /opt/light/docker-compose.yml | cut -d : -f 3)
sed -i "s?hub.dh.com/leansite/auth:${RENUM}?hub.dh.com/leansite/auth:${DRONE_BUILD_NUMBER}?" /opt/light/docker-compose.yml
docker stop jwt >/dev/null
docker rm jwt >/dev/null
cd /opt/light && docker-compose up -d
