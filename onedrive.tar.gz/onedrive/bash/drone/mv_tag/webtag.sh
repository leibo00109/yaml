#!/bin/bash
DRONE_BUILD_NUMBER=$1
RENUM=$(grep hub.dh.com/leansite/web /opt/light/docker-compose.yml | cut -d : -f 3)
sed -i "s?hub.dh.com/leansite/web:${RENUM}?hub.dh.com/leansite/web:${DRONE_BUILD_NUMBER}?" /opt/light/docker-compose.yml
docker stop leansite_web >/dev/null
docker rm leansite_web >/dev/null
cd /opt/light && docker-compose up -d
