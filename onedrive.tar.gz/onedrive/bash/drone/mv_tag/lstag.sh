#!/bin/bash
DRONE_BUILD_NUMBER=$1
RENUM=$(grep hub.dh.com/leansite/app /opt/light/docker-compose.yml | cut -d : -f 3)
sed -i "s?hub.dh.com/leansite/app:${RENUM}?hub.dh.com/leansite/app:${DRONE_BUILD_NUMBER}?" /opt/light/docker-compose.yml
cd /opt/light && docker-compose up -d
