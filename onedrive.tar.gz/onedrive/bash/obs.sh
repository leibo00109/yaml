#!/bin/bash
e=obs.cn-east-3.myhuaweicloud.com
i=ZAJTJOWVTE4KLR0KRAZL
k=jDJzov4vkufMuAvm1xY8p0C6zgTyW49Prw3Ko3dy

tt=1

while true;
        do
                t=$(stat -c %Y /opt/html/index.html)

        if [[ $tt -eq $t ]] ; then
                sleep 10
                continue
	fi

        if [[ $tt -eq "1" ]] ;then
                tt=$t
                continue
        fi

	tt=$t

	sleep 10

	\cp -f /opt/application/config.js /opt/html/static/js/config.js
	/usr/bin/obsutil rm obs://lighting/static -e=$e -i=$i -k=$k -r -f
	/usr/bin/obsutil rm obs://lighting/index.html -e=$e -i=$i -k=$k -f
	/usr/bin/obsutil cp /opt/html/static obs://lighting -e=$e -i=$i -k=$k -sc=standard -r -f
	/usr/bin/obsutil cp /opt/html/index.html obs://lighting -e=$e -i=$i -k=$k -sc=standard -f
	
	if [[ $? -eq 0 ]];then
		/usr/bin/python /usr/bin/flush_cdn.py
	fi
	

done
