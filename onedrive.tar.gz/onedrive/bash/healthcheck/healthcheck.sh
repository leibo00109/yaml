#!/bin/bash

count=`ps -ef |grep healthcheck |grep -v "grep" |wc -l`
fi
if [ ! -d "/home/software/java/logs" ]; then
  mkdir -p /home/software/java/logs
fi


if [ ! -f "/home/software/java/logs/dhlk_local.log" ]; then
#!/bin/bash

count=`ps -ef |grep healthcheck |grep -v "grep" |wc -l`
fi
if [ ! -d "/home/software/java/logs" ]; then
  mkdir -p /home/software/java/logs
fi


if [ ! -f "/home/software/java/logs/dhlk_local.log" ]; then
  touch /home/software/java/logs/dhlk_local.log
fi

if [ ! -f "/home/software/java/logs/dhlk_server_manage.log" ]; then
  touch /home/software/java/logs/dhlk_server_manage.log
fi

while true
do
  for i in '8988' '10051'
  do
    num=`(sleep 1;) | telnet 127.0.0.1 $i | grep Connected | wc -l`
    if [ $num -eq 0 ];then
         if [ $i -eq 10051 ];then
             /usr/java/jdk1.8.0_181-cloudera/bin/java -jar /opt/light/jar/dhlk_light_factory-1.0-SNAPSHOT.jar &>>/home/software/java/logs/dhlk_local.log &
         elif [ $i -eq 8988 ];then
             /usr/java/jdk1.8.0_181-cloudera/bin/java -jar /opt/light/jar/dhlk_server_manage-0.0.1-SNAPSHOT.jar &>>/home/software/java/logs/dhlk_server_manage.log &
         fi
    fi
    sleep 120
  done
done