#!/bin/bash
mkdir -p /tmp/dd && cd /tmp/dd
curl -O http://192.168.1.59:3180/a.tar.gz
tar zxf a.tar.gz && rm -f a.tar.gz
mv docker-compose /usr/bin/ && chmod u+x /usr/bin/docker-compose
mkdir -p /opt/docker-compose/gitlab/
mv docker-compose.yml gitlab.rb gitlab-secrets.json /opt/docker-compose/gitlab/
yum install *.rpm -y && rm -f *.rpm
mkdir -p /etc/docker/certs.d/hub.dh.com/
mv daemon.json /etc/docker/
cp * /etc/docker/certs.d/hub.dh.com/
systemctl enable docker && systemctl start docker
cd /opt/docker-compose/gitlab/ 
rm -rf /tmp/dd
docker-compose up -d

while true;
do
  if curl -s -I --connect-timeout 5 --max-time 10 http://127.0.0.1:11080/-/readiness | grep -q '404 Not Found' ;then
     mv -f gitlab.rb gitlab-secrets.json /opt/gitlab/config/ && docker restart gitlab
     break
  else
     echo "gitlab starts for the first time,it takes about 10 minutes"
  fi
  sleep 5
done
while true;
do
  if curl -s -I --connect-timeout 5 --max-time 10 http://127.0.0.1:11080/-/readiness | grep -q '404 Not Found' ;then
     echo "OK,please visite http://git.dh.com/"
     break
  else
     echo "Come in 3 minute"
  fi
  sleep 5
done

