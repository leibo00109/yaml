#!/bin/bash
cd /opt/html

tt1=1
tt2=1
tt3=1
tt4=1
tt5=1
tt6=1
tt7=1

jarbasic="dhlk_basic_module_service-1.0-SNAPSHOT.jar"
jarlight="dhlk_light_service-1.0-SNAPSHOT.jar"
jarweb="dhlk_web-1.0-SNAPSHOT.jar"
jarzuul="dhlk_zuul-1.0-SNAPSHOT.jar"
jarproxy="dhlk_proxy-1.0-SNAPSHOT.jar"
jarsub="dhlk_light_subscribe-1.0-SNAPSHOT.jar"
jarenergy="dhlk_basic_module_service-1.0-SNAPSHOT.jar"

function jarch(){
		cd /opt/html
		\cp -f /opt/application/${1}.yml /opt/html/BOOT-INF/classes/application-pro.yml
		/usr/java/jdk1.8.0_181-cloudera/bin/jar uf $1 BOOT-INF/classes/application-pro.yml
		\cp -f /opt/html/$1 /var/www/html/$1
}


while true;
	do
		tbasic=$(stat -c %Y /opt/html/${jarbasic})
		tlight=$(stat -c %Y /opt/html/${jarlight})
		tweb=$(stat -c %Y /opt/html/${jarweb})
		tzuul=$(stat -c %Y /opt/html/${jarzuul})
		tproxy=$(stat -c %Y /opt/html/${jarproxy})
		tsub=$(stat -c %Y /opt/html/${jarsub})
		tenergy=$(stat -c %Y /opt/html/${jarenergy})

	if [[ $tt1 -eq $tbasic && $tt2 -eq $tlight && $tt3 -eq $tweb && $tt4 -eq $tzuul && $tt5 -eq $tproxy && $tt6 -eq $tsub && $tt7 -eq $tenergy ]] ; then 
 		sleep 30 
    		continue
	fi

	if [[ $tt1 -eq "1" ]] ;then
    		tt1=$tbasic
		tt2=$tlight
    		tt3=$tweb
    		tt4=$tzuul
    		tt5=$tproxy
    		tt6=$tsub
    		tt7=$tenergy
	fi

	if [ ! -d "/opt/html/BOOT-INF/classes" ]; then
    		mkdir -p /opt/html/BOOT-INF/classes
	fi

	if [ $tzuul -gt $tt4 ] ;then
    		jarch ${jarzuul}
    		curl http://161.189.158.226:9090/zuul
    		tt4=$tzuul
    		echo ""
	fi

	sleep 30

	if [ $tweb -gt $tt3 ] ;then
		jarch ${jarweb}
    		curl http://161.189.158.226:9090/web
    		tt3=$tweb
    		echo ""
	fi

	sleep 30

	if [ $tbasic -gt $tt1 ] ;then
		jarch ${jarbasic}
   		curl http://161.189.158.226:9090/basic
    		tt1=$tbasic
    		echo ""
	fi

	sleep 30

	if [ $tlight -gt $tt2 ] ;then
		jarch ${jarlight}
    		curl http://161.189.158.226:9090/light
    		tt2=$tlight
    		echo ""
	fi

	sleep 30

	if [ $tproxy -gt $tt5 ] ;then
		\cp /opt/html/${jarproxy} /var/www/html/${jarproxy}
    		curl http://161.189.158.226:9090/proxy
    		tt5=$tproxy
    		echo ""
	fi

	sleep 30

	if [ $tsub -gt $tt6 ] ;then
		jarch ${jarsub}
    		curl http://52.83.61.136:9090/sub
    		tt6=$tsub
    		echo ""
	fi

	if [ $tenergy -gt $tt7 ] ;then
    		\cp /opt/html/${jarenergy} /var/www/html/${jarenergy}
    		curl http://161.189.158.226:9090/energy
    		tt7=$tenergy
    		echo ""
	fi

done
