#!/bin/bash
start(){
	local jtz="-Duser.timezone=Asia/Shanghai"
	local jmem="-Xmx4096m"
	local javaexe="/usr/java/jdk1.8.0_181-cloudera/bin/java"

	local javaapp=(dhlk_zuul-1.0-SNAPSHOT.jar dhlk_web-1.0-SNAPSHOT.jar dhlk_basic_module_service-1.0-SNAPSHOT.jar dhlk_appstore-1.0-SNAPSHOT.jar dhlk_hadoop-1.0-SNAPSHOT.jar dhlk_interfaces_service-1.0-SNAPSHOT.jar dhlk_fw_service-1.0-SNAPSHOT.jar dhlk_fw_web-1.0-SNAPSHOT.jar)

	if [ ! -d "/home/software/log" ]; then

		mkdir -p /home/software/log

		for app in ${javaapp[@]}

		do

			touch /home/software/log/${app}.log

		done
	fi

	for element in ${javaapp[@]}

	do
		nohup ${javaexe} ${jtz} ${jmem} -jar /home/software/java/${element} &>/home/software/log/${element}.log &

		sleep 10

                tail /home/software/log/${element}.log | grep "Tomcat started on port"

	done
}

stop(){
	local pids=$(ps aux | grep dhlk | grep -v grep | awk '{print $2}')
	
	if [[ $(echo $pids | wc -l) > 0 ]]; then

		echo $pids | xargs kill -9 

	fi

}

restart(){
	stop
	start
}

case $1 in
        "start")
                start
                ;;
        "stop")
                stop
                ;;
        "restart")
                restart
                ;;
        *)
                echo "call error,support start|stop|restart"
                ;;
esac
