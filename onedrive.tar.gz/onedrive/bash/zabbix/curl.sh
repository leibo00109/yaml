#!/bin/bash
text="zabbix告警\n"$1
curl 'https://oapi.dingtalk.com/robot/send?access_token=5a7d5a388c6bfdf2a32412cacba9876af7abd480f7b9aec6644e298f92bb7bc5' \
   -H 'Content-Type: application/json' -d '{"msgtype": "text","text": {"content": "'"$text"'"}}'