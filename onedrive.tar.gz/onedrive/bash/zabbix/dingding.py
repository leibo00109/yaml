#!/usr/bin/python
# -*- coding: utf-8 -*-
 
import requests
import json
import sys
import os
 
headers = {'Content-Type': 'application/json;charset=utf-8'}
api_url = "https://oapi.dingtalk.com/robot/send?access_token=5a7d5a388c6bfdf2a32412cacba9876af7abd480f7b9aec6644e298f92bb7bc5"
 
def msg(text):
    json_text= {"msgtype": "text","text": {"content": text}}
    print(requests.post(api_url,json.dumps(json_text),headers=headers).content)
 
if __name__ == '__main__':
    text = sys.argv[1]
    msg(text)
