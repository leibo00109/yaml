CLUSTER_NAME="kubernetes"
KUBE_USER=$1
KUBE_CERT=$1
KUBE_NAMESPACE=$1
KUBE_APISERVER=https://192.168.1.240:8443
mkdir -p /home/${KUBE_CERT}/.kube
KUBE_CONFIG=/home/${KUBE_CERT}/.kube/config

openssl genrsa -out  ${KUBE_CERT}.key 2048
openssl req -new -key ${KUBE_CERT}.key -subj "/CN=${KUBE_CERT}" -out ${KUBE_CERT}.csr
openssl x509 -req -in ${KUBE_CERT}.csr -CA /etc/kubernetes/pki/ca.crt -CAkey /etc/kubernetes/pki/ca.key -CAcreateserial -days 10000  -out ${KUBE_CERT}.crt

# 设置集群参数
kubectl config set-cluster ${CLUSTER_NAME} \
  --certificate-authority=/etc/kubernetes/pki/ca.crt \
  --embed-certs=true \
  --server=${KUBE_APISERVER} \
  --kubeconfig=${KUBE_CONFIG}
# 设置客户端认证参数
kubectl config set-credentials ${KUBE_USER} \
  --client-certificate=./${KUBE_CERT}.crt \
  --client-key=./${KUBE_CERT}.key \
  --embed-certs=true \
  --kubeconfig=${KUBE_CONFIG}

# 设置上下文参数
kubectl config set-context ${KUBE_USER}@${CLUSTER_NAME} \
  --cluster=${CLUSTER_NAME} \
  --user=${KUBE_USER} \
  --kubeconfig=${KUBE_CONFIG}

# 设置当前使用的上下文
kubectl config use-context ${KUBE_USER}@${CLUSTER_NAME} --kubeconfig=${KUBE_CONFIG}
kubectl config set-context --current --namespace=${KUBE_NAMESPACE}  --kubeconfig=${KUBE_CONFIG}
chmod 644 ${KUBE_CONFIG}
kubectl create ns ${KUBE_USER}
kubectl create rolebinding ${KUBE_USER}-binding --clusterrole=admin --user=${KUBE_USER} --namespace=${KUBE_USER}
