#!/bin/bash

dd=`date +%Y%m%d%H%M`
path=/opt/mysql_bak

[ -d $path ] || mkdir -p $path

/usr/bin/docker exec mysql mysqldump -h 127.0.0.1 -uroot -pdhlktech --databases cmf hive  > ${path}/$dd.sql

if [[ $(ls ${path} | wc -l) -gt 10 ]];then
        rm -f ${path}/$(ls $path | head -n 1)
fi

