package main

import (
	"net/http"
	"os/exec"
	"fmt"
)
func runshell(jar string ){
	command := "./runjar.sh"
	cmd := exec.Command("/bin/bash", "-c", command + " " + jar)
	
        output, err := cmd.Output()
	if err != nil {
		fmt.Printf("Execute Shell:%s failed with error:%s", command, err.Error())
		return
	}
	fmt.Printf("Execute Shell:%s finished with output:\n%s", command, string(output))
}

func basic(w http.ResponseWriter,r *http.Request){
        str := "dhlk_basic_module_service-1.0-SNAPSHOT.jar"
        runshell(str)
	w.Write([]byte(str))
	w.Write([]byte("     任务已经提交，1分钟内不要重复提交！"))
}

func light(w http.ResponseWriter,r *http.Request){
        str := "dhlk_light_service-1.0-SNAPSHOT.jar"
        runshell(str)
        w.Write([]byte(str))
	w.Write([]byte("     任务已经提交，1分钟内不要重复提交！"))
}
func web(w http.ResponseWriter,r *http.Request){
        str := "dhlk_web-1.0-SNAPSHOT.jar"
        runshell(str)
        w.Write([]byte(str))
	w.Write([]byte("     任务已经提交，1分钟内不要重复提交！"))
}
func zuul(w http.ResponseWriter,r *http.Request){
        str := "dhlk_zuul-1.0-SNAPSHOT.jar"
        runshell(str)
        w.Write([]byte(str))
	w.Write([]byte("     任务已经提交，1分钟内不要重复提交！"))
}
func proxy(w http.ResponseWriter,r *http.Request){
        str := "dhlk_proxy-1.0-SNAPSHOT.jar"
        runshell(str)
        w.Write([]byte(str))
	w.Write([]byte("     任务已经提交，1分钟内不要重复提交！"))
}

func energy(w http.ResponseWriter,r *http.Request){
        str := "energy-web.jar"
        runshell(str)
        w.Write([]byte(str))
	w.Write([]byte("     任务已经提交，1分钟内不要重复提交！"))
}
func sub(w http.ResponseWriter,r *http.Request){
        str := "dhlk_light_subscribe-1.0-SNAPSHOT.jar"
        runshell(str)
        w.Write([]byte(str))
        w.Write([]byte("     任务已经提交，1分钟内不要重复提交！"))
}

func main(){
	http.HandleFunc("/basic",basic)
	http.HandleFunc("/light",light)
	http.HandleFunc("/web",web)
	http.HandleFunc("/zuul",zuul)
	http.HandleFunc("/proxy",proxy)
	http.HandleFunc("/energy",energy)
	http.HandleFunc("/sub",sub)
	http.ListenAndServe("0.0.0.0:9090",nil)
}
