#!/bin/bash
jar=$1

sname=`basename $0`

if [ ! -d /tmp/dd ] ;then
	mkdir -p /tmp/dd 
fi

if [ -f /tmp/dd/${jar} ] ;then
	rm -f /tmp/dd/${jar}
fi

cd /tmp/dd

curl -O http://desk.dahanglink.com:11180/${jar}


if [ $? -eq 0 ] ;then
    pid=$(ps aux | grep ${jar} | grep -v grep | grep -v ${sname} | awk '{print $2}')
	if [ "$pid" != "" ];then
		echo $pid | xargs kill -9
	fi
    mv -f /tmp/dd/${jar} /home/centos/java/${jar}
    /usr/java/jdk1.8.0_181-cloudera/bin/java -jar /home/centos/java/${jar} &>/home/software/log/${jar}.log &
else
	echo "拉取文件出错"
fi

